package com.cs360.liamnunesweighttrackingapp;
import java.time.LocalDateTime;

public class DailyWeight {

    private String userName;
    private double weight;
    private LocalDateTime date;

    public DailyWeight(String userName, double weight, LocalDateTime date){
        this.userName = userName;
        this.weight = weight;
        this.date = date;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public double getWeight() {
        return weight;
    }
    public void setWeight(double weight) {
        this.weight = weight;
    }

    public LocalDateTime getDate() {
        return date;
    }
    public void setDate(LocalDateTime date) {
        this.date = date;
    }


}
