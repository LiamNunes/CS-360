package com.cs360.liamnunesweighttrackingapp;

import java.util.ArrayList;
import java.util.List;

public class UserManager {
    private List<User> users;

    public UserManager(){
        users = new ArrayList<User>();
    }

    //get a user with a given username
    public User readUser(String userName){
        //if list is null return null
        if (users == null){
            return null;
        }
        //go through list and get entry that matches userName given
        for (int i=0; i < users.size(); i++){
            if (users.get(i).getUserName().equals(userName)){
                return users.get(i);
            }
        }
        return null;
    }

    //create a user
    public void createUser(String userName, String password){
        User newUser = new User(userName, password);
        if (readUser(userName) == null){
            users.add(newUser);
        }

    }

    //update password
    public void updatePassword(String userName, String oldPassword, String newPassword){
        //if list is null return null
        if (users != null){
            for (int i=0; i < users.size(); i++){
                if (users.get(i).getUserName().equals(userName)){
                    if(users.get(i).getPassword().equals(oldPassword)){
                        users.get(i).setPassword(newPassword);
                    }
                }
            }
        }
    }

    //update weight
    public void updateWeight(String userName, double weight){
        //if list is null return null
        if (users != null) {
            for (int i = 0; i < users.size(); i++) {
                if (users.get(i).getUserName().equals(userName)) {
                    users.get(i).setTarget(weight);
                }
            }
        }
    }

    //delete user
    public void deleteUser(String userName, String password){
        //if list is null return null
        if (users != null) {
            for (int i = 0; i < users.size(); i++) {
                if (users.get(i).getPassword().equals(password)) {
                    users.remove(i);
                }
            }
        }
    }

}
