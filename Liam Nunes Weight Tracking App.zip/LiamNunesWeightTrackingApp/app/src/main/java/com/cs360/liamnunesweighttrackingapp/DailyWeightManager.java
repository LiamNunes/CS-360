package com.cs360.liamnunesweighttrackingapp;

import java.time.LocalDateTime;
import java.util.List;

public class DailyWeightManager {
    private List<DailyWeight> weights;

    public DailyWeightManager(String userName){
        //import data from database
    }

    //gets all weights for this user
    public List<DailyWeight> readWeights(){
        return weights;
    }

    //create new logged weight
    public void createWeight(String userName, double weight){
        LocalDateTime date = LocalDateTime.now();
        DailyWeight entry = new DailyWeight(userName, weight, date);
        weights.add(entry);
    }

    //change weight
    public void changeWeight(LocalDateTime date, double weight){
        for (int i = 0; i < weights.size(); i++) {
            if (weights.get(i).getDate().isEqual(date)){
                weights.get(i).setWeight(weight);
            }
        }
    }

    //delete single entry
    public void deleteEntry(LocalDateTime date){
        for (int i = 0; i < weights.size(); i++) {
            if (weights.get(i).getDate().isEqual(date)){
                weights.remove(i);
            }
        }
    }

    //delete all
    public void deleteAll(){
        for (int i = 0; i < weights.size(); i++) {
            weights.remove(i);
        }
    }

}
