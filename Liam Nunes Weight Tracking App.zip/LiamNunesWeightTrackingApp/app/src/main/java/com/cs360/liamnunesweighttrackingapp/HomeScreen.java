package com.cs360.liamnunesweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.io.Serializable;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class HomeScreen extends AppCompatActivity {
    BottomNavigationView bottomNavigationView;
    User user;

    TextView textViewTargetWeight;
    TextView textViewCurrentWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_screen);

        //find items
        textViewTargetWeight = findViewById(R.id.textViewTargetWeight);
        textViewCurrentWeight = findViewById(R.id.textViewCurrentWeight);

        //bottom navigation to get to the different screens
        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){
                case R.id.home:
                    break;
                case R.id.grid:
                    Intent intent = new Intent(this, GridScreen.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                    break;
                case R.id.settings:
                    Intent intent2 = new Intent(this, Settings.class);
                    intent2.putExtra("user", user);
                    startActivity(intent2);
                    break;
            }
            return true;
        });

        //set up user
        UserManager temp = new UserManager();
        Intent intent = getIntent();
        User user = (User)intent.getSerializableExtra("user");

        if (user.getTarget() != 0){
            textViewTargetWeight.setText((user.getTarget()+""));
        }
        else{
            textViewTargetWeight.setText("000");
        }
    }
}