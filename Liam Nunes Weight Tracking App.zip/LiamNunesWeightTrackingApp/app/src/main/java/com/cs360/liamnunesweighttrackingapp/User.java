package com.cs360.liamnunesweighttrackingapp;

import java.io.Serializable;

public class User implements Serializable {

    private String userName;
    private String password;
    private double target;


    public User(String userName, String password){
        this.userName = userName;
        this.password = password;
        this.target = 0.00;
    }

    public double getTarget() {
        return target;
    }
    public void setTarget(double target) {
        this.target = target;
    }

    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }
}
