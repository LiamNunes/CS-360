package com.cs360.liamnunesweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Settings extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    User user;
    Button buttonUpdateGoal;
    EditText editTextNewWeight;

    EditText editTextTextPasswordOld;

    EditText editTextTextPasswordNew;

    Button buttonChangePassword;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //find items
        buttonUpdateGoal = findViewById(R.id.buttonUpdateGoal);
        buttonUpdateGoal.setEnabled(false);
        editTextNewWeight = findViewById(R.id.editTextNewWeight);
        editTextNewWeight.addTextChangedListener(textWatcher);
        editTextTextPasswordOld = findViewById(R.id.editTextTextPasswordOld);
        editTextTextPasswordOld.addTextChangedListener(textWatcher);
        editTextTextPasswordNew = findViewById(R.id.editTextTextPasswordNew);
        editTextTextPasswordNew.addTextChangedListener(textWatcher);
        buttonChangePassword = findViewById(R.id.buttonChangePassword);
        buttonChangePassword.setEnabled(false);

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){
                case R.id.home:
                    Intent intent = new Intent(this, HomeScreen.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                    break;
                case R.id.grid:
                    Intent intent2 = new Intent(this, GridScreen.class);
                    intent2.putExtra("user", user);
                    startActivity(intent2);
                    break;
                case R.id.settings:
                    break;
            }
            return true;
        });

        //set up user
        UserManager temp = new UserManager();
        Intent intent = getIntent();
        User user = (User)intent.getSerializableExtra("user");
    }
    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //update password
            if(editTextTextPasswordNew.getText().toString().equals("") == false && editTextTextPasswordOld.getText().toString().equals("") == false) {//if username and password are not empty
                buttonChangePassword.setEnabled(true);
            }
            else{
                buttonChangePassword.setEnabled(false);
            }
            //update goal weight
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };
}