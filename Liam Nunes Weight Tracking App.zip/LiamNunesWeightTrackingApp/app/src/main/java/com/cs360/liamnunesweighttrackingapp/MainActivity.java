package com.cs360.liamnunesweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    EditText username;
    EditText password;
    Button login;
    Button create;
    UserManager users;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        users = new UserManager();

        //set all of the objects
        username = findViewById(R.id.editTextUsername);
        password = findViewById(R.id.editTextPassword);
        login = findViewById(R.id.loginButton);
        create = findViewById(R.id.createAccountButton);

        //disable the buttons
        login.setEnabled(false);
        create.setEnabled(false);

        //add text listener to edit texts
        username.addTextChangedListener(textWatcher);
        password.addTextChangedListener(textWatcher);
    }

    private TextWatcher textWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }
        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            if(username.getText().toString().equals("") == false && password.getText().toString().equals("") == false){//if username and password are not empty
                //enable buttons
                login.setEnabled(true);
                create.setEnabled(true);
            }
            else{//if fields are empty
                //disable buttons
                login.setEnabled(false);
                create.setEnabled(false);
            }
        }

        @Override
        public void afterTextChanged(Editable s) {
        }
    };

    //create account button functionality- adds a user to the database
    public void createAccount(View view){
        String myUserName = username.getText().toString();
        String myPassword = password.getText().toString();
        users.createUser(myUserName, myPassword);//will not add if username is in use
    }

    //login button on click- check if username and password are in database and if so sends user to home screen
    public void login(View view){
        String myUserName = username.getText().toString();
        String myPassword = password.getText().toString();

        //get password for username from database
        String getPassword = null;
        if (users.readUser(myUserName)!=null) {
            getPassword = users.readUser(myUserName).getPassword();
        }
        else{

        }

        //if password is null no user was found in database
        if (getPassword != null){
            //compare given password to stored password, if they are the same move user to homescreen
            if (getPassword.equals(myPassword)){
                //move user to homescreen and send user information
                Intent intent = new Intent(this, HomeScreen.class);
                User current = users.readUser(myUserName);
                intent.putExtra("user", current);
                startActivity(intent);
            }
        }

    }
}