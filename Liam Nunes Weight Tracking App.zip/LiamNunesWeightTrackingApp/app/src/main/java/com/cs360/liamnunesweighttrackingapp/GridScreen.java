package com.cs360.liamnunesweighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class GridScreen extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_screen);

        bottomNavigationView = findViewById(R.id.bottomNavigationView);
        bottomNavigationView.setOnItemSelectedListener(item -> {

            switch (item.getItemId()){
                case R.id.home:
                    Intent intent = new Intent(this, HomeScreen.class);
                    intent.putExtra("user", user);
                    startActivity(intent);
                    break;
                case R.id.grid:
                    Intent intent2 = new Intent(this, GridScreen.class);
                    intent2.putExtra("user", user);
                    startActivity(intent2);
                    break;
                case R.id.settings:
                    break;
            }
            return true;
        });

        //set up user
        UserManager temp = new UserManager();
        Intent intent = getIntent();
        User user = (User)intent.getSerializableExtra("user");
    }
}